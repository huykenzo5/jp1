package ebank;

import java.util.Map;
import java.util.Objects;

public class AccountBank {
    private String accountNumber;      // Số tài khoản
    private String accountHolderName;  // Tên chủ tài khoản
    private double balance;            // Số dư

    // Constructor mặc định (default values theo đề)
    public AccountBank() {
        this.accountNumber = "000000";
        this.accountHolderName = "Unknown";
        this.balance = 0.0;
    }

    // Constructor đầy đủ (có kiểm tra hợp lệ)
    public AccountBank(String accountNumber, String accountHolderName, double balance) {
        setAccountNumber(accountNumber);
        setAccountHolderName(accountHolderName);
        if (balance < 0) {
            System.out.println("Initial balance cannot be negative. Set to 0.");
            this.balance = 0.0;
        } else {
            this.balance = balance;
        }
    }

    // Getters & Setters
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) {
        if (accountNumber == null || accountNumber.isBlank()) {
            throw new IllegalArgumentException("Account number cannot be empty.");
        }
        this.accountNumber = accountNumber.trim();
    }

    public String getAccountHolderName() { return accountHolderName; }
    public void setAccountHolderName(String accountHolderName) {
        if (accountHolderName == null || accountHolderName.isBlank()) {
            throw new IllegalArgumentException("Account holder name cannot be empty.");
        }
        this.accountHolderName = accountHolderName.trim();
    }

    public double getBalance() { return balance; }
    // Theo đề: balance không được âm
    public void setBalance(double balance) {
        if (balance < 0) throw new IllegalArgumentException("Balance cannot be negative.");
        this.balance = balance;
    }

    // Hiển thị thông tin tài khoản
    public void displayAccountInfo() {
        System.out.println("----- Account Info -----");
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Account Holder : " + accountHolderName);
        System.out.println("Balance        : " + String.format("%.2f", balance));
    }

    // Nạp tiền
    public boolean deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Deposit amount must be positive.");
            return false;
        }
        balance += amount;
        System.out.println("Deposit successful. New balance: " + String.format("%.2f", balance));
        return true;
    }

    // Rút tiền
    public boolean withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdraw amount must be positive.");
            return false;
        }
        if (amount > balance) {
            System.out.println("Insufficient balance.");
            return false;
        }
        balance -= amount;
        System.out.println("Withdraw successful. New balance: " + String.format("%.2f", balance));
        return true;
    }

    // Chuyển tiền → đối tượng đích
    public boolean transferTo(AccountBank destination, double amount) {
        if (destination == null) {
            System.out.println("Destination account is null.");
            return false;
        }
        if (Objects.equals(this.accountNumber, destination.accountNumber)) {
            System.out.println("Cannot transfer to the same account.");
            return false;
        }
        if (amount <= 0) {
            System.out.println("Transfer amount must be positive.");
            return false;
        }
        if (amount > this.balance) {
            System.out.println("Insufficient balance to transfer.");
            return false;
        }
        this.balance -= amount;
        destination.balance += amount;
        System.out.println("Transfer successful. New source balance: " + String.format("%.2f", this.balance));
        return true;
    }

    // Chuyển tiền theo "số tài khoản đích" (đúng mô tả đề)
    public boolean transferTo(String destinationAccountNumber, double amount, Map<String, AccountBank> registry) {
        if (destinationAccountNumber == null || destinationAccountNumber.isBlank()) {
            System.out.println("Destination account number is invalid.");
            return false;
        }
        if (destinationAccountNumber.equals(this.accountNumber)) {
            System.out.println("Cannot transfer to the same account.");
            return false;
        }
        AccountBank dest = registry.get(destinationAccountNumber);
        if (dest == null) {
            System.out.println("Destination account not found.");
            return false;
        }
        return transferTo(dest, amount);
    }
}
