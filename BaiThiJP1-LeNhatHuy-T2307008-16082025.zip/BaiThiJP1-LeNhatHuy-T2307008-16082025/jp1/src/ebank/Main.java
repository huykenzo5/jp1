package ebank;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final Map<String, AccountBank> BANK = new HashMap<>();

    public static void main(String[] args) {
        System.out.println("=== eBanking for Customer Account (JP1 Practical) ===");

        // 1) Tạo 2 tài khoản để test
        AccountBank acc1 = createAccountFromKeyboard("SOURCE ACCOUNT");
        BANK.put(acc1.getAccountNumber(), acc1);

        AccountBank acc2 = createAccountFromKeyboard("DESTINATION ACCOUNT");
        BANK.put(acc2.getAccountNumber(), acc2);

        // 2) Vòng lặp menu giao dịch
        int choice;
        do {
            printMenu();
            choice = readInt("Choose: ");
            switch (choice) {
                case 1 -> { // Hiển thị
                    System.out.println();
                    acc1.displayAccountInfo();
                    acc2.displayAccountInfo();
                }
                case 2 -> { // Nạp tiền vào acc1
                    double amt = readDouble("Deposit amount to source: ");
                    acc1.deposit(amt);
                }
                case 3 -> { // Rút từ acc1
                    double amt = readDouble("Withdraw amount from source: ");
                    acc1.withdraw(amt);
                }
                case 4 -> { // Chuyển tiền acc1 -> ... (nhập số TK đích)
                    String destNo = readLine("Destination account number: ");
                    double amt = readDouble("Transfer amount: ");
                    acc1.transferTo(destNo, amt, BANK);
                }
                case 5 -> { // Chuyển tiền acc2 -> ...
                    String destNo = readLine("Destination account number: ");
                    double amt = readDouble("Transfer amount: ");
                    acc2.transferTo(destNo, amt, BANK);
                }
                case 0 -> System.out.println("Exit.");
                default -> System.out.println("Invalid choice.");
            }
            System.out.println();
        } while (choice != 0);

        sc.close();
    }

    // ---- Helpers ----
    private static AccountBank createAccountFromKeyboard(String title) {
        System.out.println("\n--- " + title + " ---");
        String accNo;
        while (true) {
            accNo = readLine("Account number: ");
            if (!accNo.isBlank() && !BANK.containsKey(accNo)) break;
            if (BANK.containsKey(accNo)) {
                System.out.println("Account number already exists. Try again.");
            } else {
                System.out.println("Account number cannot be empty.");
            }
        }
        String name = readLine("Account holder name: ");
        double initBal = readNonNegativeDouble("Initial balance (>=0): ");
        return new AccountBank(accNo, name, initBal);
    }

    private static void printMenu() {
        System.out.println("----------- MENU -----------");
        System.out.println("1. Show both accounts info");
        System.out.println("2. Deposit to SOURCE account");
        System.out.println("3. Withdraw from SOURCE account");
        System.out.println("4. Transfer from SOURCE -> (enter dest acc no)");
        System.out.println("5. Transfer from DESTINATION -> (enter dest acc no)");
        System.out.println("0. Exit");
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine().trim();
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.println("Please enter an integer.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine().trim();
            try {
                return Double.parseDouble(s);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static double readNonNegativeDouble(String prompt) {
        while (true) {
            double v = readDouble(prompt);
            if (v >= 0) return v;
            System.out.println("Value must be >= 0.");
        }
    }
}
